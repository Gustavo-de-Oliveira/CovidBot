from scrapinghub import ScrapinghubClient
from datetime import datetime
import schedule
import time
import requests

apikey = '3e9e7afee3c8477590ed824bca65455c'
client = ScrapinghubClient(apikey)

def atualiza():
    print("atualiza")
    project = client.get_project(440826)
    project.jobs.run('covid', job_args={})

    lJobs = []
    for job in project.jobs.iter():
        lJobs.append(job['key'])
    job = project.jobs.get(str(lJobs[0]))

    print(job)

schedule.every(5).minutes.do(atualiza)

i = 0
while True:
    schedule.run_pending()
    print(i)
    time.sleep(1)
    i += 1